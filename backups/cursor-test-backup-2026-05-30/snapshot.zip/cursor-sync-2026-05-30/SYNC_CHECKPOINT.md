# Sync checkpoint — Cursor tree vs Claude zip (2026-05-30)

**Handoff для Claude:** папка `cursor-sync-2026-05-30/` есть только в окружении Cursor. В песочнице Claude её нет — в начале сессии передать **`cursor-handoff-for-claude.zip`** (или `cursor-full.diff`). Принять за **истину**, не продолжать от `editor-core-paste` / `6.zip`.

**Для Claude:** продолжать от **этого дерева**. Иначе разъедутся правки в `index.tsx` (mount-isolation + FilmSceneBlock в EditorDocument).

---

## Контекст: путь 2 (split film page)

Cursor уже подключил **FilmSceneBlock** в реальный рендер (desktop + mobile). Стартовая точка изменилась:

| Было (план Claude) | Стало |
|--------------------|--------|
| Собирать `FilmEditor` с нуля | Продолжать **брики** film-рендера |
| Brick 1 только в zip, не в UI | Brick 1 **в UI** (`EditorDocument` + mobile `renderFilmSceneBlock`) |
| Следующий шаг неясен | **Следующий брик:** `BlockTextarea` из `renderTextarea` |
| `FilmEditor` shell | Соберётся, когда брики выедут и станет видна общая поверхность → `useEditorCore()` |

---

## База vs Claude

| | |
|---|---|
| **Git HEAD (committed)** | `a1812e4` — fix(film): align editor block layout with pagination measure |
| **Branch** | `cursor/oldwhale-lab-editor-fixes` (remote: same) |
| **Claude last zip baseline** | `editor-core-paste` (5.zip) + `split-film-page` (6.zip) — **без** правок ниже |

### Что лежит поверх zip (только у Cursor, uncommitted)

1. **`src/modes/`** — весь каркас из zip-серии (document, editor-core, export, film, registry). Untracked.
2. **`index.tsx`** — rewires на `src/modes/*` + **mount-isolation** + **mount-isolation bugfixes** + mobile `renderFilmSceneBlock`.
3. **`EditorDocument.tsx`** — **FilmSceneBlock** для `film` scene blocks (desktop).
4. **`EditorPage.tsx`** — `key={resolvedMode}`, import из `modes/registry`.
5. **`package.json`** — `"lint": "eslint src"`.
6. **`eslint.config.js`** — untracked.

Полный diff: `cursor-sync-2026-05-30/cursor-full.diff` (~1.9k строк net в index).

---

## Критичные правки Cursor (не в Claude zip)

### A. FilmSceneBlock integration

- **`EditorDocument.tsx`**: `mode === "film" && block.type === "scene" && part === "full"` → `<FilmSceneBlock … />` вместо textarea.
- **`index.tsx` ~6017**: mobile film scene → `renderFilmSceneBlock(block)` (было `renderTextarea`).

### B. mode-mount-isolation (М2)

- **`EditorPage.tsx`**: `<EditorScreen key={resolvedMode} … />`
- **`index.tsx`**: unmount → `flushProjectSave()`; меню + **LeftSidebar** → `onModeRouteChange(id)` (3 места: ~6360, ~7317, ~8409)

### C. Mount-isolation bugfixes (найдены в browser gate)

| Проблема | Fix |
|----------|-----|
| Ephemeral `proj_*` на remount, flush на смене `projectId` затирал `ow_active_project` | `projectId` init из `readLastProjectForMode`; unmount effect **`[]` deps** + `projectIdRef`/`projectNameRef` |
| `blocksRef` отставал от `setBlocks` на unmount | `updBlock` синхронно пишет `blocksRef.current` |

**Browser:** Case 1 (persist film→play→film) и Case 2 (no cross-bleed) — PASS после фиксов.

**Заметка Claude:** `[]`-effect + refs — кандидат №1 на регресс при будущих правках save; осознанный tradeoff.

---

## Browser gate status (кратко)

| Checklist | Status |
|-----------|--------|
| split-film-page (FilmSceneBlock UI) | PASS (desktop chips, Enter→cast) |
| mode-mount-isolation 1–2 | PASS |
| editor-core-blocks/scenes/history full ×4 modes | NOT RUN (sample: Enter-end, undo btn) |
| Playwright `editor-film` / `editor-play` | NOT RUN (`playwright install` завис в sandbox) |

314 unit tests pass.

---

## План возобновления (согласован с Claude)

1. Принять дерево Cursor (zip/diff) как истину; свериться с его `index.tsx`.
2. **Следующий брик:** `BlockTextarea` из `renderTextarea` — поверх дерева Cursor.
3. Оболочка `FilmEditor` — когда брики выедут.

---

## Синхронизация — порядок действий

1. **Не** накатывать свежий Claude zip поверх вслепую.
2. Взять **`cursor-full.diff`** или текущий working tree Cursor как источник правды.
3. Сверить только **новые** изменения Claude с:
   - `index.tsx` (hot zone — keyboard, save, mode switch)
   - `EditorDocument.tsx` (film render path)
   - `EditorPage.tsx` (key remount)
4. Следующий брик по плану: **`BlockTextarea`** ← extract из `renderTextarea` в `index.tsx`.
5. Playwright snapshots — главная проверка после FilmSceneBlock на desktop.

---

## Файлы в этой папке

- `SYNC_CHECKPOINT.md` — этот документ
- **`cursor-handoff-for-claude.zip`** — отдать Claude в начале сессии (modes + index + EditorDocument + diff)
- `cursor-full.diff` — полный uncommitted diff от `a1812e4`
- `cursor-stat.txt` — stat
- `git-status.txt` — status

---

## a1812e4 fixes (не регрессить)

Play/film export paths в `index.tsx` + `EditorDocument/play/*` — вручную сохранены при apply zip; не трогать при merge.
