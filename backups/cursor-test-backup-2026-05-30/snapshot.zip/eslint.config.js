// @ts-check
/*
 * ESLint flat config — minimal, focused on ONE job for now: enforce that the
 * isolated editor-mode modules under `src/modes/<id>/` never import each other.
 * This is the machine-checked half of the isolation the architecture relies on
 * (the type system is the other half once `@ts-nocheck` is removed).
 *
 * This config is inert until the toolchain is installed (kept out of
 * package.json devDependencies so `npm ci` stays in sync with the lockfile):
 *
 *     npm i -D eslint typescript-eslint
 *     npm run lint
 *
 * Once active, expand the `files`/`rules` sets to lint the wider codebase.
 */
import tseslint from "typescript-eslint";

/** Build a no-restricted-imports rule that forbids importing the given sibling modes. */
function forbidSiblingModes(self, siblings) {
  return {
    "no-restricted-imports": [
      "error",
      {
        patterns: siblings.map((sib) => ({
          group: [`**/modes/${sib}/**`, `**/modes/${sib}`],
          message: `Mode "${self}" must not import mode "${sib}" — editor modes stay isolated. Share via legacy/domain or the registry instead.`,
        })),
      },
    ],
  };
}

const ALL_MODES = ["film", "play", "short", "media", "note"];

export default tseslint.config(
  {
    ignores: ["dist", "android", "ios", "node_modules", "e2e/**", "reference*.html"],
  },
  ...ALL_MODES.map((mode) => ({
    files: [`src/modes/${mode}/**/*.{ts,tsx}`],
    rules: forbidSiblingModes(
      mode,
      ALL_MODES.filter((m) => m !== mode),
    ),
  })),
);
