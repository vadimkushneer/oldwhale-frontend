import { useRef, useState, type CSSProperties } from "react";
import { useEditorCore } from "../editor-core/useEditorCore";
import { PlayScene, PlaySpacer, PlayLine } from "./PlayBlocks";
import {
  canSplitInline,
  cycleBlockType,
  computeMergeJoiner,
  insertBlocksAfter,
  mergeAdjacentBlocks,
  nextEnterType,
  splitBlockText,
  type EditorBlock,
} from "../editor-core/blocks";
import { EDITOR_MODES } from "../registry";
import { autoH } from "../../legacy/util/doc";
import { BG, SURF, T1 } from "../../legacy/ui/tokens";

/**
 * PlayEditorNext — increment 1 of the standalone play editor (variant A, path 2).
 *
 * A real per-mode editor: it owns its document via `useEditorCore` and renders
 * through the shared PlayBlocks bricks, with a play keyboard assembled from the
 * pure block helpers. NO `mode === "..."` branches, no shared god-component frame.
 *
 * Scope of THIS increment (deliberately partial, browser-gated):
 *   - render + edit play blocks (scene / spacer / line / act) via core + bricks
 *   - keyboard: Enter (split / new block by nextEnterType), Backspace-at-start
 *     (merge into previous), Tab (cycle block type)
 *   - in-memory document seeded from the play starter (registry)
 * NOT yet: real project load/save, toolbar, scene navigator, import/export,
 *   title page, AI. Production `/editor/play` stays on EditorScreen until this
 *   reaches parity — this is reachable only behind `?next=1`.
 */
const PLAY_ACCENT = "#a78bfa";
const newId = () => "p" + Math.random().toString(36).slice(2, 10);

export function PlayEditorNext() {
  const modeRef = useRef("play");
  const [, setSaved] = useState(true);
  const scheduleAutosaveRef = useRef(() => {});
  const getInitialBlocks = () => EDITOR_MODES.play.initialBlocks() as unknown as EditorBlock[];

  const core = useEditorCore({
    mode: "play",
    modeRef,
    setSaved,
    getInitialBlocks: getInitialBlocks as never,
    scheduleAutosaveRef,
  });

  const defs = EDITOR_MODES.play.blockDefs;
  const blocks = core.blocks as unknown as EditorBlock[];

  const onKey = (e: React.KeyboardEvent<HTMLElement>, block: EditorBlock) => {
    const ta = e.currentTarget as HTMLTextAreaElement;
    const cursor = ta.selectionStart ?? 0;
    const cur = core.blocksRef.current as unknown as EditorBlock[];

    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      const def = defs.find((d) => d.type === block.type);
      const atEnd = cursor >= (block.text?.length ?? 0);
      if (canSplitInline(block.type) && !atEnd) {
        const { before, after } = splitBlockText(block.text, cursor);
        const nid = newId();
        const split = insertBlocksAfter(
          cur.map((b) => (b.id === block.id ? { ...b, text: before } : b)),
          block.id,
          [{ id: nid, type: block.type, text: after }],
        );
        core.applyBlocks(split as never);
        setTimeout(() => core.setFoc(nid), 0);
      } else {
        const nid = newId();
        const nType = nextEnterType(def, defs);
        const next = insertBlocksAfter(cur, block.id, [{ id: nid, type: nType, text: "" }]);
        core.applyBlocks(next as never);
        setTimeout(() => core.setFoc(nid), 0);
      }
      return;
    }

    if (e.key === "Backspace" && cursor === 0) {
      const idx = cur.findIndex((b) => b.id === block.id);
      if (idx > 0) {
        const prev = cur[idx - 1];
        e.preventDefault();
        const { joiner } = computeMergeJoiner(prev.text, block.text);
        const merged = mergeAdjacentBlocks(cur, prev.id, block.id, joiner);
        core.applyBlocks(merged as never);
        setTimeout(() => core.setFoc(prev.id), 0);
      }
      return;
    }

    if (e.key === "Tab") {
      e.preventDefault();
      const nType = cycleBlockType(defs, block.type, ["scene", "act", "spacer"]);
      if (nType) {
        core.applyBlocks(cur.map((b) => (b.id === block.id ? { ...b, type: nType } : b)) as never);
      }
    }
  };

  const renderSearchOverlay = () => null;

  const common = {
    blockRefs: core.blockRefs as never,
    docFont: "Times New Roman",
    autoH,
    updBlock: core.updBlock as never,
    setFoc: core.setFoc as never,
    setFocId: core.setFocId as never,
    onKey,
    renderSearchOverlay,
  };

  const renderBlock = (block: EditorBlock) => {
    if (block.type === "scene") return <PlayScene key={String(block.id)} block={block} blocks={blocks} {...common} />;
    if (block.type === "spacer")
      return (
        <PlaySpacer
          key={String(block.id)}
          block={block}
          focId={core.focId as never}
          accentColor={PLAY_ACCENT}
          setFoc={core.setFoc as never}
          onKey={onKey}
        />
      );
    if (block.type === "line")
      return <PlayLine key={String(block.id)} block={block} updBlockName={core.updBlockName as never} {...common} />;
    // fallback (act, etc.) — a plain editable line for this increment
    const actStyle: CSSProperties = { fontWeight: "bold", textAlign: "center", textTransform: "uppercase" };
    return (
      <textarea
        key={String(block.id)}
        ref={(el) => { core.blockRefs.current[String(block.id)] = el; }}
        value={block.text || ""}
        onChange={(e) => { core.updBlock(block.id, e.target.value); autoH(e.target); }}
        onFocus={() => core.setFoc(block.id)}
        onKeyDown={(e) => onKey(e, block)}
        rows={1}
        style={{
          display: "block", width: "100%", border: "none", outline: "none", resize: "none",
          background: "transparent", color: T1, fontFamily: "'Times New Roman',serif", fontSize: "16px",
          margin: "8px 0", padding: 0, ...(block.type === "act" ? actStyle : {}),
        }}
      />
    );
  };

  return (
    <div style={{ width: "100%", height: "100%", overflow: "auto", background: BG, padding: "40px 0" }}>
      <div style={{ maxWidth: "640px", margin: "0 auto", background: SURF, borderRadius: "8px", padding: "48px 64px", minHeight: "60vh" }}>
        <div style={{ fontSize: "11px", letterSpacing: "1px", color: PLAY_ACCENT, marginBottom: "24px", fontFamily: "'Courier New',monospace" }}>
          PLAYEDITOR · NEXT (увеличение 1 · ?next=1 · прод не затронут)
        </div>
        {blocks.map(renderBlock)}
      </div>
    </div>
  );
}
